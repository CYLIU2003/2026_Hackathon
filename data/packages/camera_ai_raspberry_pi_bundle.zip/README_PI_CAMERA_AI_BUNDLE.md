# Raspberry Pi Camera AI Bundle

This ZIP contains the camera AI runtime files for the A1 Bear Honey Buffet prototype.

Safety boundary: camera AI is only an additional perception signal. Honey release still
requires the Arduino Uno Q contact-pad state machine and fail-safe RELEASE_OFF behavior.

Included model:

```text
models/yolo_bear_ncnn_model
```

On the Raspberry Pi:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r raspberry_pi/camera_ai/requirements.txt
python raspberry_pi/camera_ai/run_camera_ai.py --device /dev/video0 --terminal-status --max-iterations 5
```
