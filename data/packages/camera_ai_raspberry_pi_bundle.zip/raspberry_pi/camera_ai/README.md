# Camera AI Bear Approach Detection

This prototype adds a Raspberry Pi camera AI module for bear approach detection.
It uses a USB camera and a lightweight YOLO model to publish camera-derived state as JSON Lines.

This module is only an additional perception layer. It does not replace the Arduino Uno Q contact-pad logic, `paw_contact`, `raw_contact_value`, resistance/contact thresholds, or the fail-safe `release_state` decision.

## Hardware

- Raspberry Pi 4B 4GB
- BUFFALO BSW500M USB web camera
- No real sensors are required for this camera AI module
- No real animal testing is part of this prototype

## Setup

Run commands from the repository root:

```bash
cd ~/Desktop/2026_Hackathon
```

Create the virtual environment and install the camera AI + dashboard
dependencies:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r raspberry_pi/camera_ai/requirements.txt
python -m pip install -r raspberry_pi/dashboard/requirements.txt
```

## Quick Start: Camera AI + Remote Dashboard

Use this for the normal demo. It starts the Camera AI process, saves the latest
annotated recognition image, and starts the browser dashboard.

```bash
cd ~/Desktop/2026_Hackathon
source .venv/bin/activate
./scripts/run_demo.sh
```

Then open this from another PC, tablet, or phone on the same network, or through
Tailscale:

```text
http://<pi-ip>:8080
```

What you should see:

```text
- Camera AI View: latest camera frame with detection boxes and status text
- Camera AI State: event, camera/model status, confidence, approach state
- Contact Pad State: latest contact-pad / release CSV state when available
```

The Camera AI image shown by the dashboard is written here:

```text
data/debug_frames/latest_camera_ai.jpg
```

That image includes the latest camera frame, detection boxes, event,
confidence, approach state, and inference time. It is for remote monitoring
only and does not change the Arduino/contact-pad RELEASE_ON/OFF safety logic.

To stop the demo, press `Ctrl+C` in the terminal running `./scripts/run_demo.sh`.

If you also want to start the Arduino Uno Q serial logger:

```bash
RUN_SERIAL_LOGGER=1 ./scripts/run_demo.sh
```

If port 8080 is already in use:

```bash
DASHBOARD_PORT=18080 ./scripts/run_demo.sh
```

Then open:

```text
http://<pi-ip>:18080
```

## Start Camera AI Only

Use this when you only want to confirm camera recognition and CSV/image output,
without the dashboard:

```bash
source .venv/bin/activate
python -m raspberry_pi.camera_ai.run_camera_ai \
  --device /dev/video0 \
  --terminal-status \
  --no-jsonl \
  --save-debug-frames
```

One-shot smoke test:

```bash
python -m raspberry_pi.camera_ai.run_camera_ai \
  --device /dev/video0 \
  --terminal-status \
  --no-jsonl \
  --once \
  --save-debug-frames
```

Expected output includes a line like:

```text
event=AI_NO_BEAR camera=ok model=ok bear=no approaching=no device=/dev/video0
```

## Start Dashboard Only

Use this when Camera AI is already running and writing
`data/debug_frames/latest_camera_ai.jpg`:

```bash
source .venv/bin/activate
python raspberry_pi/dashboard/app.py \
  --log-dir data/logs \
  --camera-log-file data/logs/camera_ai_log.csv \
  --debug-frame-dir data/debug_frames \
  --host 0.0.0.0 \
  --port 8080
```

Open:

```text
http://<pi-ip>:8080
```

## Assisted Raspberry Pi Bring-up

Use this order when setting up the module on the Raspberry Pi:

1. Confirm the USB camera is visible to Linux.
2. Create and activate the project virtual environment.
3. Run `camera_test.py` and confirm it saves a debug frame.
4. Export or place the lightweight model at `models/yolo_bear_ncnn_model`.
5. Run `run_camera_ai.py --once --terminal-status`.
6. Run `run_camera_ai.py --max-iterations 5 --terminal-status` and check JSON Lines plus CSV output.

If any step fails, stop there and capture the command plus output before moving
to the next step. The most useful first outputs to share are:

```bash
uname -a
python3 --version
lsusb
ls /dev/video*
v4l2-ctl --list-devices
groups
```

Do not use `sudo pip`. Keep Python packages inside `.venv`.

## Headless / CUI Operation

The default configuration is safe for Raspberry Pi operation without a monitor:
`use_display` is `false`, so OpenCV does not open a GUI window.

For SSH or Tailscale sessions, use compact terminal status output:

```bash
source .venv/bin/activate
python raspberry_pi/camera_ai/run_camera_ai.py \
  --device /dev/video0 \
  --terminal-status \
  --no-jsonl \
  --max-iterations 5
```

Example CUI status line:

```text
2026-06-07T17:50:00+09:00 event=AI_BEAR_DETECTED camera=ok model=ok bear=yes approaching=no conf=0.82 area=18.0% infer_ms=120.5 device=/dev/video0
```

Use `--terminal-status` without `--no-jsonl` when another process needs JSON
Lines from stdout. The human-readable CUI status is written to stderr, so stdout
remains machine-readable:

```bash
python raspberry_pi/camera_ai/run_camera_ai.py \
  --device /dev/video0 \
  --terminal-status \
  > data/logs/camera_ai.jsonl \
  2> data/logs/camera_ai.status.log
```

To watch the CSV log from a terminal:

```bash
tail -f data/logs/camera_ai_log.csv
```

## Remote Browser View Details

Camera AI saves an annotated latest frame by default:

```text
data/debug_frames/latest_camera_ai.jpg
```

The frame contains the latest camera image, detection boxes, event, confidence,
approach state, and inference time. It is for remote monitoring only and does
not change release safety logic.

Start Camera AI and the browser dashboard together:

```bash
source .venv/bin/activate
./scripts/run_demo.sh
```

Then open this from another machine on the same network, or through Tailscale:

```text
http://<pi-ip>:8080
```

If the image area says `No camera frame yet`, check:

```bash
tail -f data/logs/camera_ai.status.log
ls -l data/debug_frames/latest_camera_ai.jpg
```

You can force frame output from the Camera AI process:

```bash
python -m raspberry_pi.camera_ai.run_camera_ai \
  --device /dev/video0 \
  --terminal-status \
  --no-jsonl \
  --save-debug-frames
```

Install camera tools on Raspberry Pi:

```bash
sudo apt update
sudo apt install -y python3-venv python3-pip v4l-utils libgl1 libglib2.0-0
```

Check the camera:

```bash
lsusb
ls /dev/video*
v4l2-ctl --list-devices
v4l2-ctl --device=/dev/video0 --all
v4l2-ctl --device=/dev/video0 --list-formats-ext
```

Create a Python virtual environment and install Python dependencies:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r raspberry_pi/camera_ai/requirements.txt
```

Place a lightweight exported YOLO model at the primary path configured in
`config.camera_ai.yaml`:

```text
models/yolo_bear_ncnn_model
```

Raw training data and intermediate Colab artifacts are intentionally ignored by
Git. The selected runtime files under `models/yolo_bear_ncnn_model` and
`models/yolo_bear.pt` may be committed intentionally when using GitHub to
transfer the trained model to the Raspberry Pi.
The current runtime also accepts the transferred trained PyTorch weights at:

```text
models/yolo_bear.pt
```

At startup, `run_camera_ai.py` tries the existing configured model paths in
order. On Raspberry Pi 4B, use the preferred NCNN export plus the `ncnn`
Python runtime from `requirements.txt`. The raw PyTorch `.pt` fallback is kept
for development and transfer convenience, but it can be slower and may not be
stable on every Pi/PyTorch wheel combination.

The Raspberry Pi 4B 4GB profile uses:

```text
capture: 320x240 MJPG at 10 fps
YOLO input_size: 256
primary model: models/yolo_bear_ncnn_model
fallbacks: models/yolo_bear_int8.tflite, models/yolo_bear.onnx, models/yolo_bear.pt
inference interval: about 2.0 sec
remote dashboard JPEG update interval: about 1.0 sec
```

For prototype bring-up, this file may be a COCO-pretrained nano model. The
filename can be `yolo_bear.pt` even while the contents are generic COCO weights:

```bash
mkdir -p models
python - <<'PY'
from ultralytics import YOLO
YOLO("yolov8n.pt")
print("downloaded / loaded yolov8n.pt")
PY
cp yolov8n.pt models/yolo_bear.pt
```

COCO includes the `bear` class. Stuffed toys may be detected as `teddy bear`
instead of `bear`; that is acceptable for early camera/model smoke testing but
not enough to command release.

Export the `.pt` model into the lighter default NCNN runtime format:

```bash
source .venv/bin/activate
python raspberry_pi/camera_ai/export_lightweight_yolo.py \
  --source models/yolo_bear.pt \
  --format ncnn \
  --imgsz 256 \
  --overwrite
```

The script places and prints the runtime path:

```text
models/yolo_bear_ncnn_model
```

If NCNN is not available in the current environment, export a fallback format:

```bash
python raspberry_pi/camera_ai/export_lightweight_yolo.py \
  --source models/yolo_bear.pt \
  --format onnx \
  --imgsz 256 \
  --overwrite
```

If you only want to confirm the camera first, the YOLO model is not required for
`camera_test.py`. The model is required for `run_camera_ai.py`.

After installing dependencies, verify that Python can import the required
packages:

```bash
source .venv/bin/activate
python - <<'PY'
import cv2
import yaml
import ultralytics
print("cv2", cv2.__version__)
print("yaml", yaml.__version__)
print("ultralytics", ultralytics.__version__)
PY
```

If the camera does not open, make sure the user can access video devices:

```bash
groups
sudo usermod -aG video $USER
```

Log out and log in again after adding the user to the `video` group.

## Camera Test

Run one-frame capture with a camera index:

```bash
source .venv/bin/activate
python raspberry_pi/camera_ai/camera_test.py
```

Or pass the target Linux video device path explicitly:

```bash
source .venv/bin/activate
python raspberry_pi/camera_ai/camera_test.py --device /dev/video0
```

For the BUFFALO BSW500M USB camera on Raspberry Pi 4B, `/dev/video0` is the
image capture device. `/dev/video1` is metadata and must not be used by OpenCV.
The default profile tries this first:

```text
/dev/video0, MJPG, 640x480, 15 fps
```

If this fails, the script automatically falls back to:

```text
/dev/video0, MJPG, 320x240, 15 fps
/dev/video0, YUYV, 640x480, 15 fps
/dev/video0, YUYV, 320x240, 15 fps
```

Check supported V4L2 formats before changing code:

```bash
v4l2-ctl --list-devices
v4l2-ctl --device=/dev/video0 --list-formats-ext
```

To force only one profile:

```bash
python raspberry_pi/camera_ai/camera_test.py --device /dev/video0 --single-profile
```

The script prints available `/dev/video*` paths, selected width/height/fps/fourcc,
the frame shape, and saves one image at `outputs/camera_test.jpg` by default.

## Run AI Detection

Use the default config:

```bash
source .venv/bin/activate
python raspberry_pi/camera_ai/run_camera_ai.py --config raspberry_pi/camera_ai/config.camera_ai.yaml
```

The default config uses `/dev/video0`, V4L2, `MJPG`, `320x240`, and `10 fps`,
with fallback profiles if frame capture fails.

Override camera and model:

```bash
source .venv/bin/activate
python -m raspberry_pi.camera_ai.run_camera_ai --device /dev/video0 --model models/yolo_bear.pt
```

Run one inference cycle:

```bash
source .venv/bin/activate
python -m raspberry_pi.camera_ai.run_camera_ai \
  --device /dev/video0 \
  --model models/yolo_bear.pt \
  --once \
  --terminal-status
```

For a short smoke test without running forever:

```bash
source .venv/bin/activate
python -m raspberry_pi.camera_ai.run_camera_ai \
  --device /dev/video0 \
  --model models/yolo_bear.pt \
  --max-iterations 5 \
  --terminal-status
```

## View Camera AI From Your PC Over SSH

Recommended approach: run the camera AI web viewer on the Raspberry Pi, then
open it from this PC through SSH local port forwarding. This does not require a
monitor, desktop session, VNC, or X11 forwarding on the Raspberry Pi.

On the Raspberry Pi:

```bash
cd ~/Desktop/2026_Hackathon
git pull
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r raspberry_pi/camera_ai/requirements.txt
python raspberry_pi/camera_ai/web_camera_ai.py \
  --device /dev/video0 \
  --host 127.0.0.1 \
  --port 8081 \
  --terminal-status
```

On this PC, in a separate terminal:

```powershell
ssh -L 8081:127.0.0.1:8081 <pi-ssh-host>
```

Then open this URL on the PC:

```text
http://127.0.0.1:8081
```

The page shows an MJPEG camera stream with detection boxes plus the latest AI
status. JSON status is also available at:

```text
http://127.0.0.1:8081/status.json
```

Keep the viewer bound to `127.0.0.1` on the Raspberry Pi when using SSH
forwarding. Use `--host 0.0.0.0` only on a trusted private network.

X11 forwarding with `ssh -X` can show OpenCV windows, but it is usually slower
and more fragile on Windows. The web viewer is the preferred demo path.

## Prepare Public Bear Training Data

The training-data path is optional for the MVP runtime, but it lets the team
fine-tune a small bear detector from public images before real local data is
available.

Prepare data on a PC first; do not install the dataset tooling on the Raspberry
Pi unless you intentionally want to download and train there.
Use Python 3.10 or newer for Ultralytics training and model export.

```bash
python raspberry_pi/camera_ai/prepare_bear_training_data.py \
  --source coco2017 \
  --max-images 80 \
  --overwrite \
  --package
```

The default path downloads public COCO 2017 `bear` detections, converts them to
Ultralytics YOLO format, writes:

```text
data/datasets/bear_public_yolo/dataset.yaml
```

and, with `--package`, creates a Pi-copyable dataset ZIP:

```text
data/packages/bear_public_yolo_pi.zip
```

The generated dataset and ZIP are ignored by Git.
The COCO annotation ZIP is cached under `data/datasets/_downloads/` and is not
included in the Pi dataset package.

If you want Open Images instead of COCO, install the optional FiftyOne dataset
tooling and change the source:

```bash
python -m pip install -r raspberry_pi/camera_ai/requirements.dataset.txt
python raspberry_pi/camera_ai/prepare_bear_training_data.py \
  --source open-images-v7 \
  --split-limit train=160 \
  --split-limit validation=40 \
  --overwrite \
  --package
```

Train a lightweight prototype model:

```bash
python raspberry_pi/camera_ai/train_bear_yolo.py \
  --data data/datasets/bear_public_yolo/dataset.yaml \
  --imgsz 256 \
  --epochs 30 \
  --batch 8
```

The trained PyTorch model is copied to:

```text
models/yolo_bear.pt
```

Export it to the Raspberry Pi preferred runtime format:

```bash
python raspberry_pi/camera_ai/export_lightweight_yolo.py \
  --source models/yolo_bear.pt \
  --format ncnn \
  --imgsz 256 \
  --overwrite
```

Create a Raspberry Pi copy-ready runtime bundle:

```bash
python raspberry_pi/camera_ai/package_pi_camera_ai.py --require-model
```

The bundle is written to:

```text
data/packages/camera_ai_raspberry_pi_bundle.zip
```

Copy that ZIP to the Raspberry Pi repository root and unzip it. It contains the
camera AI runtime files plus the best available model path, preferring
`models/yolo_bear_ncnn_model`.

## Train With Google Colab Free GPU

If the local PC should only prepare data and Colab should handle training, use
the notebook:

```text
notebooks/colab_bear_yolo_training.ipynb
```

VSCode flow:

1. Open `notebooks/colab_bear_yolo_training.ipynb` in VSCode.
2. Use the Google Colab extension to connect the notebook to a Colab runtime.
3. In Colab, choose a GPU runtime such as T4.
4. Run all cells.

By default, the notebook downloads the public COCO 2017 `bear` training data
inside Colab and builds the YOLO dataset there. No local dataset upload is
required.

If you prefer to use the ZIP prepared on this PC, change `DATASET_MODE` in the
notebook to `upload_zip` or `google_drive_zip`, then provide:

```text
data/packages/bear_public_yolo_pi.zip
```

The notebook installs the pinned camera-AI training dependencies, checks
`torch.cuda`, trains `yolov8n.pt` on the bear YOLO dataset, copies the trained
model to:

```text
models/yolo_bear.pt
```

and tries to export the Raspberry Pi preferred runtime model:

```text
models/yolo_bear_ncnn_model
```

If NCNN export fails in the free Colab environment, it creates this fallback:

```text
models/yolo_bear.onnx
```

At the end, download:

```text
a1_camera_ai_colab_artifacts.zip
```

Place that ZIP at the repository root on this PC. Then import it and build the
final Raspberry Pi runtime package:

```powershell
.\.venv\Scripts\python.exe raspberry_pi\camera_ai\import_colab_artifacts.py `
  --artifact .\a1_camera_ai_colab_artifacts.zip `
  --clean-existing-models
```

The Pi-copy-ready runtime bundle will be:

```text
data/packages/camera_ai_raspberry_pi_bundle.zip
```

For GitHub-based Raspberry Pi transfer, commit the imported runtime model files
under `models/` or the final bundle above. The `.gitignore` keeps raw training
datasets, COCO caches, debug frames, logs, and intermediate ZIPs out of Git.

## Output

The module emits JSON Lines:

```json
{"timestamp":"2026-06-07T12:00:00+09:00","source":"camera_ai","camera_device":"/dev/video0","ai_camera_ok":true,"ai_model_ok":true,"ai_bear_detected":true,"ai_bear_confidence":0.82,"ai_bear_box_area_ratio":0.18,"ai_bear_approaching":true,"event":"AI_BEAR_APPROACHING","inference_time_ms":120.5}
```

If the camera, model, or runtime fails, the output is fail-safe:

```text
ai_bear_approaching=false
```

CSV logs are saved separately from contact-pad logs at `data/logs/camera_ai_log.csv` by default.

## Approach Logic

`ai_bear_approaching` becomes true only when all configured conditions are satisfied:

- target class matches, default `bear`
- confidence is at least `confidence_threshold`
- bounding-box area ratio is at least `approach_area_ratio_threshold`
- the condition is true for `consecutive_required` checks

The camera AI module does not command honey release. A future integration must still require contact confirmation, honey availability, system safety, and no emergency stop before any release request.

## Known Limitations

- A YOLO model is not included in Git.
- Raspberry Pi 4B should use nano models exported to NCNN/TFLite/ONNX and low
  input sizes such as 256.
- Camera detection can be wrong; it is only a support signal.
- Current integration publishes AI state only and does not modify the Arduino release decision.

## Troubleshooting

### `externally-managed-environment`

Use the project virtual environment instead of system Python:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r raspberry_pi/camera_ai/requirements.txt
```

### `manpath: can't set the locale`

This warning is not usually related to camera capture, but you can clean it up
with:

```bash
sudo raspi-config
```

Then choose `Localisation Options` and generate/select the locale you use, such
as `en_US.UTF-8` or `ja_JP.UTF-8`.

### `ImportError: libGL.so.1`

Install the OpenCV runtime library:

```bash
sudo apt install -y libgl1
```

### `ERROR: camera could not be opened`

Check the camera device and permissions:

```bash
lsusb
ls /dev/video*
v4l2-ctl --list-devices
groups
```

For the target BUFFALO BSW500M setup, keep OpenCV on `/dev/video0`. Do not use
`/dev/video1`; it is the metadata node.

### `ERROR: camera opened but no frame was captured`

The device node exists, but OpenCV did not receive an image frame. Check which
video node exposes capture frames and which pixel formats it supports:

```bash
v4l2-ctl --list-devices
v4l2-ctl --device=/dev/video0 --all
v4l2-ctl --device=/dev/video0 --list-formats-ext
```

Then try the most likely alternatives:

```bash
python raspberry_pi/camera_ai/camera_test.py --device /dev/video0
python raspberry_pi/camera_ai/camera_test.py --device /dev/video0 --backend any
python raspberry_pi/camera_ai/camera_test.py --device /dev/video0 --fourcc YUYV --single-profile
python raspberry_pi/camera_ai/camera_test.py --device /dev/video0 --width 320 --height 240 --fourcc MJPG --single-profile
```

If OpenCV still captures no frame, check whether V4L2 itself can stream from the
USB camera. For the target BUFFALO BSW500M setup, use `/dev/video0` as the
capture node and leave the metadata node alone.

```bash
v4l2-ctl --device=/dev/video0 --stream-mmap --stream-count=10 --stream-to=/tmp/camera-test.raw
ls -lh /tmp/camera-test.raw
```

If `/tmp/camera-test.raw` is created and has a non-zero size, the camera and
kernel driver are working and the issue is likely OpenCV/backend related.

### `VIDIOC_STREAMON returned -1 (Protocol error)`

This means V4L2 itself could not start streaming from the USB camera, so the
problem is below Python/OpenCV. Check for device busy, USB/power problems, and
kernel driver errors:

```bash
fuser -v /dev/video0
dmesg -T | grep -iE "usb|uvc|video|camera|error|fail|protocol" | tail -80
vcgencmd get_throttled
```

Then unplug and replug the USB camera, or try another Raspberry Pi USB port. If
the camera is connected through a hub, try connecting it directly or using a
powered hub.

Try forcing a supported capture format before streaming:

```bash
v4l2-ctl --device=/dev/video0 \
  --set-fmt-video=width=640,height=480,pixelformat=MJPG \
  --stream-mmap --stream-count=10 --stream-to=/tmp/camera-test.raw

v4l2-ctl --device=/dev/video0 \
  --set-fmt-video=width=640,height=480,pixelformat=YUYV \
  --stream-mmap --stream-count=10 --stream-to=/tmp/camera-test-yuyv.raw
```

You can also test with a simple camera utility:

```bash
sudo apt install -y fswebcam
fswebcam -d /dev/video0 -r 640x480 --jpeg 85 /tmp/fswebcam.jpg
ls -lh /tmp/fswebcam.jpg
```

If V4L2 and `fswebcam` both fail, replace the USB cable/camera or test the same
camera on another computer before debugging the Python code further.

Recommended next checks:

```bash
sudo reboot
```

After reboot, unplug and replug the USB camera, then try:

```bash
lsusb -t
v4l2-ctl --device=/dev/video0 \
  --set-fmt-video=width=320,height=240,pixelformat=MJPG \
  --stream-mmap --stream-count=10 --stream-to=/tmp/camera-test-320.raw
```

If it still fails, reload the UVC driver once and retry:

```bash
fuser -v /dev/video0
sudo modprobe -r uvcvideo
sudo modprobe uvcvideo
v4l2-ctl --device=/dev/video0 \
  --set-fmt-video=width=320,height=240,pixelformat=MJPG \
  --stream-mmap --stream-count=10 --stream-to=/tmp/camera-test-320.raw
```

Some non-compliant UVC cameras need a bandwidth quirk:

```bash
fuser -v /dev/video0
sudo modprobe -r uvcvideo
sudo modprobe uvcvideo quirks=0x80
v4l2-ctl --device=/dev/video0 \
  --set-fmt-video=width=320,height=240,pixelformat=MJPG \
  --stream-mmap --stream-count=10 --stream-to=/tmp/camera-test-320.raw
```

If the quirk fixes the camera, make it persistent:

```bash
echo 'options uvcvideo quirks=0x80' | sudo tee /etc/modprobe.d/uvcvideo.conf
```

If `modprobe: FATAL: Module uvcvideo is in use` appears, first find and stop
users of the video devices:

```bash
fuser -v /dev/video0
fuser -v /dev/snd/*
```

If no user process is shown, unload dependent camera/audio modules in this
order, then load `uvcvideo` again:

```bash
sudo modprobe -r snd-usb-audio
sudo modprobe -r uvcvideo
sudo modprobe uvcvideo quirks=0x80
sudo modprobe snd-usb-audio
```

On desktop Raspberry Pi OS, audio services may keep `snd-usb-audio` busy. If
needed, stop them temporarily before unloading the modules:

```bash
systemctl --user stop pipewire pipewire-pulse wireplumber pulseaudio 2>/dev/null || true
sudo modprobe -r snd-usb-audio
sudo modprobe -r uvcvideo
sudo modprobe uvcvideo quirks=0x80
sudo modprobe snd-usb-audio
```

If the module still cannot be unloaded, use the persistent quirk route and
reboot. This is often simpler than fighting modules that are already in use:

```bash
echo 'options uvcvideo quirks=0x80' | sudo tee /etc/modprobe.d/uvcvideo.conf
sudo reboot
```

After reboot, reconnect the camera and test before opening any camera app:

```bash
v4l2-ctl --device=/dev/video0 \
  --set-fmt-video=width=320,height=240,pixelformat=MJPG \
  --stream-mmap --stream-count=10 --stream-to=/tmp/camera-test-320.raw
ls -lh /tmp/camera-test-320.raw
```

### `AI_MODEL_LOAD_ERROR`

Check that the model file exists at the configured path:

```bash
ls -ld models/yolo_bear_ncnn_model
```

Or pass the model path explicitly:

```bash
python raspberry_pi/camera_ai/run_camera_ai.py --model models/bear_yolo.pt --once
```
